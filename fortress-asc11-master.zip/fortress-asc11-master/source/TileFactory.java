import javafx.scene.image.Image;
import java.util.Map;

/**
 * Creates instances of the various types of tile from characters in the save
 * file along with any additional information.
 *
 * @author Alex
 * @author Stephen
 */

public final class TileFactory {
    private Map<String, Image> images;

    public static final class MapChars {
        //Tiles
        public static final char WALL = '#';
        public static final char GROUND = ' ';
        public static final char WATER = '~';
        public static final char FIRE = '&';
        public static final char GOAL = '!';
        public static final char KEY_DOOR = '@';
        public static final char SCORE_DOOR = '$';
        public static final char TELEPORTER = 'T';
        //Items
        public static final char TOKEN = 'O';
        public static final char FIRE_BOOTS = '"';
        public static final char FLIPPERS = 'Y';
        public static final char RED_KEY = 'r';
        public static final char BLUE_KEY = 'b';
        public static final char GREEN_KEY = 'g';
        // Misc
        public static final char EMPTY_TILE = '.';
    }

    /**
     * TileFactory contructor.
     * @param img image when drawn
     */
    public TileFactory(final Map<String, Image> img) {
        images = img;
    }

    /**
     * Getter for tile.
     * @param c character in save file
     * @return instance of tile
     */
    public Tile getTile(final char c) {
        return getTile(c, new String[0]);
    }

    /**
     * Getter for a tile and its additional information.
     * @param c character in save file
     * @param additionalInfo additional information in save file
     * @return instance of tile and any additional information
     */
    public Tile getTile(final char c, final String additionalInfo) {
        return getTile(c, additionalInfo.split(GameState.INFO_DELIMITER));
    }

    /**
     * Getter for tile with characteristics processed from additional
     * information.
     * @param c character in save file
     * @param additionalInfo additional information from save file
     * @return type of tile
     */
    public Tile getTile(final char c, final String[] additionalInfo) {
        switch (c) {
            case MapChars.GROUND:
                return new Ground(c, images);
            case MapChars.WALL:
                return new Wall(c, images);
            case MapChars.FIRE:
                return new Hazard(c, images, Item.FIRE_BOOTS);
            case MapChars.WATER:
                return new Hazard(c, images, Item.FLIPPERS);
            case MapChars.GOAL:
                return new Goal(c, images);
            case MapChars.KEY_DOOR:
                return new KeyDoor(c, images, keyFromChar(
                        additionalInfo[0].charAt(0)));
            case MapChars.SCORE_DOOR:
                return new ScoreDoor(c, images, Integer.parseInt(
                        additionalInfo[0]));
            case MapChars.TELEPORTER:
                return new Teleporter(c, images, Integer.parseInt(
                        additionalInfo[0]),
                        Integer.parseInt(additionalInfo[1]));
            case MapChars.TOKEN:
                return new Ground(c, images, Item.TOKEN);
            case MapChars.FIRE_BOOTS:
                return new Ground(c, images, Item.FIRE_BOOTS);
            case MapChars.FLIPPERS:
                return new Ground(c, images, Item.FLIPPERS);
            case MapChars.RED_KEY:
                return new Ground(c, images, Item.RED_KEY);
            case MapChars.GREEN_KEY:
                return new Ground(c, images, Item.GREEN_KEY);
            case MapChars.BLUE_KEY:
                return new Ground(c, images, Item.BLUE_KEY);
            case MapChars.EMPTY_TILE:
                return null;
            default:
                return null;
        }
    }

    /**
     * Key type required to open instance of key door generated.
     * @param c character in save file
     * @return key type
     */
    private Item keyFromChar(final char c) {
        switch (c) {
            case MapChars.RED_KEY:
                return Item.RED_KEY;
            case MapChars.GREEN_KEY:
                return Item.GREEN_KEY;
            case MapChars.BLUE_KEY:
                return Item.BLUE_KEY;
            default:
                return null;
        }
    }
}
