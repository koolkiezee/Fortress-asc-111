import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

import java.util.Map;

/**
 * Door is a tile that acts as a wall unless the player has the correct
 * condition to open it.
 *
 * @author Alex
 * @author Stephen
 */
public abstract class Door extends Tile {
    private static final String DOOR_DOWN_2_IMG = "door_bottom_2.png";
    private static final String DOOR_DOWN_1_IMG = "door_bottom_1.png";
    private static final String DOOR_DOWN_3_IMG = "door_bottom_3.png";
    private static final String DOOR_LEFT_2_IMG = "door_left_2.png";
    private static final String DOOR_LEFT_1_IMG = "door_left_1.png";
    private static final String DOOR_LEFT_3_IMG = "door_left_3.png";
    private static final String DOOR_RIGHT_2_IMG = "door_right_2.png";
    private static final String DOOR_RIGHT_1_IMG = "door_right_1.png";
    private static final String DOOR_RIGHT_3_IMG = "door_right_3.png";
    private static final String DOOR_UP_2_IMG = "door_top_2.png";
    private static final String DOOR_UP_1_IMG = "door_top_1.png";
    private static final String DOOR_UP_3_IMG = "door_top_3.png";

    private static final String UNLOCK_SOUND = "door.wav";


    static boolean drewLeftDoor = false;
    private boolean locked;

    /**
     * Creates a locked door.
     * @param mapChar character from save file
     * @param img image to be drawn
     */
    public Door(final char mapChar, final Map<String, Image> img) {
        super(mapChar,  img);
        locked = true;
    }

    /**
     * Getter for locked.
     * @return locked boolean
     */
    protected final boolean isLocked() {
        return locked;
    }

    /**
     * Unlocked setter for locked boolean.
     */
    protected final void unlock() {
        locked = false;
        setMapChar(TileFactory.MapChars.GROUND);
        setSound(UNLOCK_SOUND);
    }

    /**
     * Boolean that represents if the door graphic should be facing left or not.
     * @return boolean related to direction the door is facing in game
     */
    protected final boolean isLeft() {
        Tile up = getUpNeighbour();
        Tile down = getDownNeighbour();

        return up != null && up.getMapChar() == TileFactory.MapChars.WALL
                && (((Wall) up).isTopMid() || ((Wall) up).isConvexTopLeft()
                    || ((Wall) up).isInternal())
                && down != null && down.getMapChar()
                == TileFactory.MapChars.WALL
                && (((Wall) down).isBottomMid()
                || ((Wall) down).isConvexBottomLeft()
                    || ((Wall) down).isInternal());
    }

    /**
     * Boolean that represents if the door graphic should be facing right
     * or not.
     * @return boolean related to direction the door is facing in game
     */
    protected final boolean isRight() {
        Tile up = getUpNeighbour();
        Tile down = getDownNeighbour();

        return up != null && up.getMapChar() == TileFactory.MapChars.WALL
                && (((Wall) up).isTopMid() || ((Wall) up).isConvexTopRight()
                    || ((Wall) up).isInternal())
                && down != null && down.getMapChar()
                == TileFactory.MapChars.WALL
                && (((Wall) down).isBottomMid()
                || ((Wall) down).isConvexBottomRight()
                    || ((Wall) down).isInternal());
    }

    /**
     * Boolean that represents if the door graphic should be facing up or not.
     * @return boolean related to direction the door is facing in game
     */
    protected final boolean isUp() {
        Tile left = getLeftNeighbour();
        Tile right = getRightNeighbour();

        return left != null && left.getMapChar() == TileFactory.MapChars.WALL
                && (((Wall) left).isLeftMid()
                || ((Wall) left).isConvexTopLeft()
                    || ((Wall) left).isInternal())
                && right != null && right.getMapChar()
                == TileFactory.MapChars.WALL
                && (((Wall) right).isRightMid()
                || ((Wall) right).isConvexTopRight()
                    || ((Wall) right).isInternal());
    }

    /**
     * Boolean that represents if the door graphic should be facing down or
     * not.
     * @return boolean related to direction the door is facing in game
     */
    protected final boolean isDown() {
        Tile left = getLeftNeighbour();
        Tile right = getRightNeighbour();

        return left != null && left.getMapChar()
                == TileFactory.MapChars.WALL
                && (((Wall) left).isLeftMid()
                || ((Wall) left).isConvexBottomLeft()
                    || ((Wall) left).isInternal())
                && right != null && right.getMapChar()
                == TileFactory.MapChars.WALL
                && (((Wall) right).isRightMid()
                || ((Wall) right).isConvexBottomRight()
                    || ((Wall) right).isInternal());
    }

    /**
     * Boolean that checks if the tile is walkable by an instance of enemy or
     * not.
     * @param e instance of enemy
     * @return boolean walkable or not
     */
    public boolean isPassable(final Enemy e) {
        if (isLocked()) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Gets the minimap colour for a door.
     * @return colour graphic for the instance of door
     */
    @Override
    public Color getMinimapColor() {
        return isLocked() ? Color.BROWN : super.getMinimapColor();
    }

    /**
     * Draws the graphic for an instance door.
     * @param gc drawable feature of teh canavas
     * @param x x coordinate of tile
     * @param y y coordinate of tile
     * @param animationTick runtime of animation
     */
    @Override
    public void draw(final GraphicsContext gc, final double x, final double y,
                     final int animationTick) {
        if (isLeft()) {
            gc.drawImage(getImage(GROUND_IMG), x, y);
            gc.drawImage(getImage(DOOR_LEFT_1_IMG), x, y - GameState.TILE_RES);
            gc.drawImage(getImage(DOOR_LEFT_2_IMG), x, y);
            gc.drawImage(getImage(DOOR_LEFT_3_IMG), x, y + GameState.TILE_RES);
        } else if (isRight()) {
            gc.drawImage(getImage(GROUND_IMG), x, y);
            gc.drawImage(getImage(DOOR_RIGHT_1_IMG), x, y - GameState.TILE_RES);
            gc.drawImage(getImage(DOOR_RIGHT_2_IMG), x, y);
            gc.drawImage(getImage(DOOR_RIGHT_3_IMG), x, y + GameState.TILE_RES);
        } else if (isUp()) {
            gc.drawImage(getImage(GROUND_IMG), x, y);
            gc.drawImage(getImage(DOOR_UP_1_IMG), x - GameState.TILE_RES, y);
            gc.drawImage(getImage(DOOR_UP_2_IMG), x, y);
            gc.drawImage(getImage(DOOR_UP_3_IMG), x + GameState.TILE_RES, y);
        } else if (isDown()) {
            gc.drawImage(getImage(GROUND_IMG), x, y);
            gc.drawImage(getImage(DOOR_DOWN_1_IMG), x - GameState.TILE_RES, y);
            gc.drawImage(getImage(DOOR_DOWN_2_IMG), x, y);
            gc.drawImage(getImage(DOOR_DOWN_3_IMG), x + GameState.TILE_RES, y);
        }
    }
}
